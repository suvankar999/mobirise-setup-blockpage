$(document).ready(function () {
    $(".menubar").click(function () {
      $(".x-button").show();
      $(".menubar").hide();
      $(".btn-text").fadeIn(300);
      $(".mobirise_row").css("background-color", "#000");
      $(".mobirise_row").css("padding-bottom", "100px");
      $(".mobirise_row").css("padding-top", "5px");
      $(".mobirise_row").css("transition", "all 0.5s ease-in-out");
    });
    $(".x-button").click(function () {
      $(".x-button").hide();
      $(".menubar").show();
      $(".btn-text").fadeOut(300);
      $(".mobirise_row").css("padding-top", "20px");
      $(".mobirise_row").css("background-color", "transparent");
      $(".mobirise_row").css("transition", "all 0.5s ease-in-out");
    
    });

  });
